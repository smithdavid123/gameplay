
NAME = 'legion_cache_fetch'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['legion_cache_fetch']

