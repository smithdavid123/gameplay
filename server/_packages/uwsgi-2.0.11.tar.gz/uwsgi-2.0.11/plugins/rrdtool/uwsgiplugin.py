
NAME='rrdtool'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['rrdtool']
