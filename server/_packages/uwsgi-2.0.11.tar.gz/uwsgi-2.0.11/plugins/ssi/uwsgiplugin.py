NAME='ssi'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['ssi']
