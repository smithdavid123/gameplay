NAME='echo'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['echo_plugin']
