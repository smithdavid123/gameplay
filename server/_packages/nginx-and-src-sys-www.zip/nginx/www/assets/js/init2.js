if (!isLogin) {
    window.location.href = '/login.html';
}