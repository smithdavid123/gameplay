if (isLogin) {
    window.location.href = '/home.html';
}