rm -rf dist*
mv ~/dist.zip ./
unzip dist.zip

